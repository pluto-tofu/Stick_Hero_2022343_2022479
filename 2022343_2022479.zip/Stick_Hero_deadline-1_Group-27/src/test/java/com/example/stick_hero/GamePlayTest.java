package com.example.stick_hero;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class GamePlayTest {
    @Test
    void chanceofcherry() {
        GamePlay gp = new GamePlay();
        int result = gp.chanceofcherry();
        assertEquals(0,result);
    }
    @Test
    void save_test(){
        Scanner in = null;
        PrintWriter out = null;
        try{
            in = new Scanner(new BufferedReader(new FileReader("save_score.txt")));
            int a = in.nextInt();
            int b = in.nextInt();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        finally {
            assert in != null;
            in.close();
        }
    }
}